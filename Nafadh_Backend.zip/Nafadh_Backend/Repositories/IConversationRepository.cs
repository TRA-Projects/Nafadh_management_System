using Nafadh_Backend.DTOs;
using Nafadh_Backend.DTOs.CompanyPayment;
using Nafadh_Backend.Enums;
using Nafadh_Backend.Models;

namespace Nafadh_Backend.Repositories
{
    public interface IConversationRepository
    {
        Task<List<NFD_SupportTicket>> GetAsync(
            NFD_ConversationType? type,
            int? participantUserId,
            NFD_SupportTicketStatus? status
        );

        Task<NFD_SupportTicket?> GetByIdAsync(
            int conversationId
        );

        //GET all batch groups for admin view
        Task<List<AdminBatchGroupListDTO>> GetAdminBatchGroupsAsync();

        //GET all messages for a batch group for admin view
        Task<List<AdminBatchGroupMessageDTO>?> GetAdminBatchGroupMessagesAsync(
    int conversationId
);

        Task<NFD_SupportTicket> CreateAsync(
            NFD_SupportTicket conversation,
            NFD_Message firstMessage
        );

        Task<NFD_Message> AddMessageAsync(
            NFD_Message message
        );
        Task<int> CreateBatchGroupAsync(
    CreateBatchGroupDTO dto
);

        Task<bool> IsBatchGroupMemberAsync(
    int conversationId,
    int userId
);
        Task<int?> GetBatchIdAsync(
    int conversationId
);
        Task<string?> GetBatchNameAsync(int conversationId);
        Task UpdateStatusAsync(
            int conversationId,
            NFD_SupportTicketStatus status
        );
        Task<Dictionary<int, int>> GetGroupUnreadCountsAsync(
    int userId,
    List<int> conversationIds
);
        Task MarkMessagesAsReadAsync(
            int conversationId,
            int readerUserId
        );

        // Returns the number of conversations containing unread incoming replies.
        Task<int> GetUnreadConversationCountAsync(
            int userId,
            bool includeAllConversations
        );
    }
}