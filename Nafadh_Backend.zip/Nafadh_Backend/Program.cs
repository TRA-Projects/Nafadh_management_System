using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.FileProviders;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi;
using Microsoft.OpenApi.Models;
using Nafadh_Backend;
using Nafadh_Backend.Filters;
using Nafadh_Backend.Interfaces;
using Nafadh_Backend.Repositories;
using Nafadh_Backend.Services;
using Nafadh_Backend.Settings;
using QuestPDF.Infrastructure;
using System.Security.Claims;
using System.Text;



namespace Nafadh_Backend
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);
            QuestPDF.Settings.License = LicenseType.Community;
            QuestPDF.Settings.UseSystemFonts = true;


            // Add services to the container.
            builder.Services.AddControllers(options =>
            {
                options.Filters.Add<ApiExceptionFilter>();
            })
  .AddJsonOptions(options =>
  {
      // Serialize enums as strings instead of numbers
      options.JsonSerializerOptions.Converters.Add(
          new System.Text.Json.Serialization.JsonStringEnumConverter());

      // Prevent circular reference errors
      options.JsonSerializerOptions.ReferenceHandler =
          System.Text.Json.Serialization.ReferenceHandler.IgnoreCycles;
  });

            // CORS Policy to fix Swagger fetch issues
            builder.Services.AddCors(options =>
            {
                options.AddPolicy("AllowAll", policy =>
                {
                    policy.AllowAnyOrigin()
                          .AllowAnyMethod()
                          .AllowAnyHeader();
                });
            });

            // Management -> original Training reference-catalog API (no Training backend changes).
            builder.Services.AddHttpClient("TrainingConstants", client =>
                client.Timeout = TimeSpan.FromSeconds(15));
            builder.Services.AddScoped<ITrainingConstantsService, TrainingConstantsService>();

            // EF Core - SQL Server
            builder.Services.AddDbContext<Nafadhcontext>(options =>
                options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

            // ── JWT Authentication ─────────────────────────────────────────────
            builder.Services.AddScoped<IJwtTokenService, JwtTokenService>();

            var jwtKey = builder.Configuration["Jwt:Key"];
            var jwtIssuer = builder.Configuration["Jwt:Issuer"];
            var jwtAudience = builder.Configuration["Jwt:Audience"];

            builder.Services
                .AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
                .AddJwtBearer(options =>
                {
                    options.MapInboundClaims = false;

                    options.TokenValidationParameters = new TokenValidationParameters
                    {
                        ValidateIssuer = true,
                        ValidateAudience = true,
                        ValidateLifetime = true,
                        ValidateIssuerSigningKey = true,
                        ValidIssuer = jwtIssuer,
                        ValidAudience = jwtAudience,
                        RoleClaimType = ClaimTypes.Role,
                        ClockSkew = TimeSpan.Zero,
                        IssuerSigningKey = new SymmetricSecurityKey(
                                                       Encoding.UTF8.GetBytes(jwtKey))
                    };

                    options.Events = new JwtBearerEvents
                    {
                        OnAuthenticationFailed = context =>
                        {
                            var error = context.Exception.Message;
                            return Task.CompletedTask;
                        },
                        OnTokenValidated = context =>
                        {
                            var claims = context.Principal.Claims.ToList();
                            return Task.CompletedTask;
                        },
                        OnChallenge = context =>
                        {
                            var error = context.Error;
                            var desc = context.ErrorDescription;
                            return Task.CompletedTask;
                        }
                    };
                });

            builder.Services.AddAuthorization();
            // ── end JWT Authentication ─────────────────────────────────────────────

            // Repositories & Services (one pair per domain entity)
            builder.Services.AddScoped<IUserRepository, UserRepository>();
            builder.Services.AddScoped<IUserService, UserService>();
            builder.Services.AddScoped<IRoleRepository, RoleRepository>();
            builder.Services.AddScoped<IRoleService, RoleService>();
            builder.Services.AddScoped<IPermissionRepository, PermissionRepository>();
            builder.Services.AddScoped<IPermissionService, PermissionService>();
            builder.Services.AddScoped<IRolePermissionRepository, RolePermissionRepository>();
            builder.Services.AddScoped<IRolePermissionService, RolePermissionService>();
            builder.Services.AddScoped<IAuditLogRepository, AuditLogRepository>();
            builder.Services.AddScoped<IAuditLogService, AuditLogService>();
            builder.Services.AddScoped<ICompanyRepository, CompanyRepository>();
            builder.Services.AddScoped<ICompanyService, CompanyService>();
            builder.Services.AddScoped<ICompanyBranchRepository, CompanyBranchRepository>();
            builder.Services.AddScoped<ICompanyBranchService, CompanyBranchService>();
            builder.Services.AddScoped<ICompanySupervisorRepository, CompanySupervisorRepository>();
            builder.Services.AddScoped<ICompanySupervisorService, CompanySupervisorService>();
            builder.Services.AddScoped<IDepartmentRepository, DepartmentRepository>();
            builder.Services.AddScoped<IDepartmentService, DepartmentService>();
            builder.Services.AddScoped<ICompanyProgramRepository, CompanyProgramRepository>();
            builder.Services.AddScoped<ICompanyProgramService, CompanyProgramService>();
            builder.Services.AddScoped<ITrainerRepository, TrainerRepository>();
            builder.Services.AddScoped<ITrainerService, TrainerService>();
            builder.Services.AddScoped<ICoursePlanExecutionRepository, CoursePlanExecutionRepository>();
            builder.Services.AddScoped<ICoursePlanExecutionService, CoursePlanExecutionService>();
            builder.Services.AddScoped<CoursePlanReader>();
            builder.Services.AddScoped<ITraineeRepository, TraineeRepository>();
            builder.Services.AddScoped<ITraineeService, TraineeService>();
            builder.Services.AddScoped<ITrackRepository, TrackRepository>();
            builder.Services.AddScoped<ITrackService, TrackService>();
            builder.Services.AddScoped<IProgramRepository, ProgramRepository>();
            builder.Services.AddScoped<IProgramService, ProgramService>();
            builder.Services.AddScoped<IBatchRepository, BatchRepository>();
            builder.Services.AddScoped<IBatchService, BatchService>();
            builder.Services.AddScoped<IBatchTrainerRepository, BatchTrainerRepository>();
            builder.Services.AddScoped<IBatchTrainerService, BatchTrainerService>();
            builder.Services.AddScoped<IEnrollmentRepository, EnrollmentRepository>();
            builder.Services.AddScoped<IEnrollmentService, EnrollmentService>();
            builder.Services.AddScoped<IModuleRepository, ModuleRepository>();
            builder.Services.AddScoped<IModuleService, ModuleService>();
            builder.Services.AddScoped<ILessonRepository, LessonRepository>();
            builder.Services.AddScoped<ILessonService, LessonService>();
            builder.Services.AddScoped<ITrainingMaterialRepository, TrainingMaterialRepository>();
            builder.Services.AddScoped<ITrainingMaterialService, TrainingMaterialService>();
            builder.Services.AddScoped<ITraineeModuleProgressRepository, TraineeModuleProgressRepository>();
            builder.Services.AddScoped<ITraineeModuleProgressService, TraineeModuleProgressService>();

            // User Guide Progress
            builder.Services.AddScoped<IUserGuideProgressRepository, UserGuideProgressRepository>();
            builder.Services.AddScoped<IUserGuideProgressService, UserGuideProgressService>();
            builder.Services.AddScoped<ISessionRepository, SessionRepository>();
            builder.Services.AddScoped<ISessionService, SessionService>();
            builder.Services.AddScoped<ISessionAttendanceRepository, SessionAttendanceRepository>();
            builder.Services.AddScoped<ISessionAttendanceService, SessionAttendanceService>();
            builder.Services.AddScoped<IDailyAttendanceRepository, DailyAttendanceRepository>();
            builder.Services.AddScoped<IDailyAttendanceService, DailyAttendanceService>();
            builder.Services.AddScoped<
                ITrainerAttendanceRepository,
                TrainerAttendanceRepository>();
            builder.Services.AddScoped<
                ITrainerAttendanceService,
                TrainerAttendanceService>();
            builder.Services.AddScoped<IExcuseRepository, ExcuseRepository>();
            builder.Services.AddScoped<IExcuseService, ExcuseService>();
            builder.Services.AddScoped<ITaskRepository, TaskRepository>();
            builder.Services.AddScoped<ITaskService, TaskService>();
            builder.Services.AddScoped<IRubricRepository, RubricRepository>();
            builder.Services.AddScoped<IRubricService, RubricService>();
            builder.Services.AddScoped<ISubmissionRepository, SubmissionRepository>();
            builder.Services.AddScoped<ISubmissionService, SubmissionService>();
            builder.Services.AddScoped<IProjectRepository, ProjectRepository>();
            builder.Services.AddScoped<IProjectService, ProjectService>();
            builder.Services.AddScoped<IProjectMemberRepository, ProjectMemberRepository>();
            builder.Services.AddScoped<IProjectMemberService, ProjectMemberService>();
            builder.Services.AddScoped<IEvaluationTemplateRepository, EvaluationTemplateRepository>();
            builder.Services.AddScoped<IEvaluationTemplateService, EvaluationTemplateService>();
            builder.Services.AddScoped<IEvaluationCriterionRepository, EvaluationCriterionRepository>();
            builder.Services.AddScoped<IEvaluationCriterionService, EvaluationCriterionService>();
            builder.Services.AddScoped<IEvaluationRepository, EvaluationRepository>();
            builder.Services.AddScoped<IEvaluationService, EvaluationService>();
            builder.Services.AddScoped<IWarningRepository, WarningRepository>();
            builder.Services.AddScoped<IWarningService, WarningService>();
            builder.Services.AddScoped<IRiskWarningService, RiskWarningService>();
            builder.Services.AddScoped<ISupportTicketRepository, SupportTicketRepository>();
            builder.Services.AddScoped<ISupportTicketService, SupportTicketService>();
            builder.Services.AddScoped<INotificationRepository, NotificationRepository>();
            builder.Services.AddScoped<INotificationService, NotificationService>();
            builder.Services.AddScoped<INotificationSummaryService, NotificationSummaryService>();
            builder.Services.AddScoped<IAnnouncementRepository, AnnouncementRepository>();
            builder.Services.AddScoped<IAnnouncementService, AnnouncementService>();
            builder.Services.AddScoped<IMessageRepository, MessageRepository>();
            builder.Services.AddScoped<IMessageService, MessageService>();
            builder.Services.AddScoped<ICertificateRepository, CertificateRepository>();
            builder.Services.AddScoped<ICertificateService, CertificateService>();
            builder.Services.AddScoped<ITrainerCertificateRepository, TrainerCertificateRepository>();
            builder.Services.AddScoped<ITrainerCertificateService, TrainerCertificateService>();
            builder.Services.AddScoped<IReportRepository, ReportRepository>();
            builder.Services.AddScoped<IReportService, ReportService>();

            // Admin Supervisor Reports
            builder.Services.AddScoped<
                IAdminSupervisorReportsRepository,
                AdminSupervisorReportsRepository>();

            builder.Services.AddScoped<
                IAdminSupervisorReportsService,
                AdminSupervisorReportsService>();

            builder.Services.AddScoped<ISystemSettingRepository, SystemSettingRepository>();
            builder.Services.AddScoped<ISystemSettingService, SystemSettingService>();
            builder.Services.AddScoped<ITraineePaymentRepository, TraineePaymentRepository>();
            builder.Services.AddScoped<ITraineePaymentService, TraineePaymentService>();
            builder.Services.AddScoped<ITraineePaymentScheduleRepository, TraineePaymentScheduleRepository>();
            builder.Services.AddScoped<ITraineePaymentScheduleService, TraineePaymentScheduleService>();
            builder.Services.AddScoped<ICompanyPaymentRepository, CompanyPaymentRepository>();
            builder.Services.AddScoped<ICompanyPaymentService, CompanyPaymentService>();
            builder.Services.AddScoped<ICompanyPaymentScheduleRepository, CompanyPaymentScheduleRepository>();
            builder.Services.AddScoped<ICompanyPaymentScheduleService, CompanyPaymentScheduleService>();
            builder.Services.AddScoped<IQuizRepository, QuizRepository>();
            builder.Services.AddScoped<IQuizService, QuizService>();
            builder.Services.AddScoped<IQuestionBankRepository, QuestionBankRepository>();

            builder.Services.AddScoped<IQuestionBankService, QuestionBankService>();
            builder.Services.AddScoped<IQuizQuestionRepository, QuizQuestionRepository>();

            builder.Services.AddScoped<IQuizQuestionService, QuizQuestionService>();
            builder.Services.AddScoped<IQuizAttemptRepository, QuizAttemptRepository>();

            builder.Services.AddScoped<IQuizAttemptService, QuizAttemptService>();

            builder.Services.AddScoped<IQuizResultRepository, QuizResultRepository>();

            builder.Services.AddScoped<IQuizResultService, QuizResultService>();
            builder.Services.AddScoped<IQuestionBankRepository, QuestionBankRepository>();
            builder.Services.AddScoped<IQuestionBankService, QuestionBankService>();

            builder.Services.AddScoped<IQuizAccessService, QuizAccessService>();
            builder.Services.AddScoped<IQuizProctoringService, QuizProctoringService>();
            // Trainer Portal - LiveKit automatic attendance tracking.
            builder.Services.AddScoped<SessionAttendanceTrackingService>();
            builder.Services.AddHostedService<ProctoringCleanupService>();

            builder.Services.AddScoped<ITraineeEvaluationRepository, TraineeEvaluationRepository>();
            builder.Services.AddScoped<ITraineeEvaluationService, TraineeEvaluationService>();
            //change by admin team
            builder.Services.AddScoped<IRemediationRepository, RemediationRepository>();
            builder.Services.AddScoped<IRemediationService, RemediationService>();

            builder.Services.AddScoped<ITraineeSkillRepository, TraineeSkillRepository>();
            builder.Services.AddScoped<ITraineeSkillService, TraineeSkillService>();

            // ── NEW registrations (backend upgrade - Phase 2 Contract Alignment) ──
            builder.Services.AddScoped<IConversationRepository, ConversationRepository>();
            builder.Services.AddScoped<IConversationService, ConversationService>();
            builder.Services.AddScoped<IFeedbackRepository, FeedbackRepository>();
            builder.Services.AddScoped<IFeedbackService, FeedbackService>();
            builder.Services.AddScoped<IBadgeRepository, BadgeRepository>();
            builder.Services.AddScoped<IBadgeService, BadgeService>();
            builder.Services.AddScoped<IBadgeEvaluationService, BadgeEvaluationService>();

            // ── NEW registrations (backend upgrade - Phase 3 Contract Alignment) ──

            builder.Services.AddScoped<ILessonFeedbackRepository, LessonFeedbackRepository>();
            builder.Services.AddScoped<ILessonFeedbackService, LessonFeedbackService>();


            // Email settings
            builder.Services.Configure<EmailSettings>(builder.Configuration.GetSection("EmailSettings"));
            builder.Services.Configure<AbsenceWarningSettings>(builder.Configuration.GetSection("AbsenceWarnings"));
            // Trainer live sessions
            builder.Services.AddScoped<TrainerLiveSessionService>();
            // Trainer Portal - Register LiveKit Cloud room service.
            builder.Services.AddScoped<ILiveKitService, LiveKitService>();

            // Trainer session recordings
            builder.Services.AddScoped<TrainerSessionRecordingService>();
            // Automatic absence warnings
            builder.Services.AddScoped<IEmailService, EmailService>();
            builder.Services.AddScoped<IAbsenceWarningService, AbsenceWarningService>();

            // Company self-registration (public register + approval/rejection + login gate)
            builder.Services.AddScoped<ICompanyRegistrationService, CompanyRegistrationService>();

            // ── Swagger with JWT support ───────────────────────────────────────
            builder.Services.AddEndpointsApiExplorer();

            builder.Services.AddSwaggerGen(c =>
            {
                c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
                {
                    Name = "Authorization",
                    Type = SecuritySchemeType.Http,
                    Scheme = "bearer",
                    BearerFormat = "JWT",
                    In = ParameterLocation.Header,
                    Description = "Enter your JWT token in the box below"
                });

                c.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        {
            new OpenApiSecurityScheme
            {
                Reference = new OpenApiReference
                {
                    Type = ReferenceType.SecurityScheme,
                    Id   = "Bearer"
                }
            },
            new List<string>()
        }
    });
            });

            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.UseHttpsRedirection();
            // STATIC FILES INSIDE WWWROOT
            app.UseStaticFiles();
            // EXTERNAL TRAINING MATERIAL FILES
            // =====================================================
            // Physical storage path outside the project
            var trainingMaterialsPath = builder.Configuration["Storage:TrainingMaterialsPath"];


            // Public URL path used by the browser
            var trainingMaterialsRequestPath = builder.Configuration["Storage:TrainingMaterialsRequestPath"] ?? "/uploads/training-materials";

            if (!string.IsNullOrWhiteSpace(trainingMaterialsPath))


            {
                // Create the external folder
                // if it does not exist yet
                Directory.CreateDirectory(trainingMaterialsPath);


                // Allow the browser to access files
                // stored outside wwwroot
                app.UseStaticFiles(new StaticFileOptions

                {
                    FileProvider = new PhysicalFileProvider(trainingMaterialsPath),

                    RequestPath = trainingMaterialsRequestPath

                }
                );
            }
            // =====================================================
            // EXTERNAL TRAINER PROFILE IMAGES
            // =====================================================

            // Physical folder where trainer profile images
            // are stored outside the project.
            var trainerProfileImagesPath =
                builder.Configuration[
                    "Storage:TrainerProfileImagesPath"
                ];


            // Public URL path used by the browser.
            var trainerProfileImagesRequestPath =
                builder.Configuration[
                    "Storage:TrainerProfileImagesRequestPath"
                ]
                ?? "/uploads/trainer-profiles";


            if (
                !string.IsNullOrWhiteSpace(
                    trainerProfileImagesPath
                )
            )
            {
                // Create the external folder
                // if it does not exist yet.
                Directory.CreateDirectory(
                    trainerProfileImagesPath
                );


                // Map the public URL to the
                // physical trainer image folder.
                app.UseStaticFiles(
                    new StaticFileOptions
                    {
                        FileProvider =
                            new PhysicalFileProvider(
                                trainerProfileImagesPath
                            ),

                        RequestPath =
                            trainerProfileImagesRequestPath
                    }
                );
            }


            // =====================================================
            // EXTERNAL TRAINEE PROFILE IMAGES
            // =====================================================

            // Physical folder where trainee profile images
            // are stored outside the project.
            var traineeProfileImagesPath =
                builder.Configuration[
                    "Storage:TraineeProfileImagesPath"
                ];


            // Public URL path used by the browser.
            var traineeProfileImagesRequestPath =
                builder.Configuration[
                    "Storage:TraineeProfileImagesRequestPath"
                ]
                ?? "/uploads/trainee-profiles";


            if (
                !string.IsNullOrWhiteSpace(
                    traineeProfileImagesPath
                )
            )
            {
                // Create the external folder
                // if it does not exist yet.
                Directory.CreateDirectory(
                    traineeProfileImagesPath
                );


                // Map the public URL to the
                // physical trainee image folder.
                app.UseStaticFiles(
                    new StaticFileOptions
                    {
                        FileProvider =
                            new PhysicalFileProvider(
                                traineeProfileImagesPath
                            ),

                        RequestPath =
                            traineeProfileImagesRequestPath
                    }
                );
            }
            // =====================================================
            // EXCUSE PROOF FILES
            // =====================================================

            var excuseProofsPath =
                builder.Configuration[
                    "Storage:ExcuseProofsPath"
                ];

            var excuseProofsRequestPath =
                builder.Configuration[
                    "Storage:ExcuseProofsRequestPath"
                ]
                ?? "/uploads/excuse-proofs";


            if (
                !string.IsNullOrWhiteSpace(
                    excuseProofsPath
                )
            )
            {
                Directory.CreateDirectory(
                    excuseProofsPath
                );

                app.UseStaticFiles(
                    new StaticFileOptions
                    {
                        FileProvider =
                            new PhysicalFileProvider(
                                excuseProofsPath
                            ),

                        RequestPath =
                            excuseProofsRequestPath
                    }
                );
            }

            // =====================================================
            // EXTERNAL TRAINER ATTENDANCE PROOF FILES
            // =====================================================
            var trainerAttendanceProofsPath =
                builder.Configuration["Storage:TrainerAttendanceProofsPath"];

            var trainerAttendanceProofsRequestPath =
                builder.Configuration["Storage:TrainerAttendanceProofsRequestPath"]
                ?? "/uploads/trainer-attendance-proofs";

            if (!string.IsNullOrWhiteSpace(trainerAttendanceProofsPath))
            {
                Directory.CreateDirectory(trainerAttendanceProofsPath);
                app.UseStaticFiles(new StaticFileOptions
                {
                    FileProvider = new PhysicalFileProvider(trainerAttendanceProofsPath),
                    RequestPath = trainerAttendanceProofsRequestPath
                });
            }

            // Enable CORS middleware here
            app.UseCors("AllowAll");
            app.UseStaticFiles();
            app.UseAuthentication();
            app.UseAuthorization();

            app.MapControllers();

            app.Run();
        }
    }
}